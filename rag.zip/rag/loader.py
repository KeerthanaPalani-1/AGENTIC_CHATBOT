from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

def load_documents(path="data/sample_docs.md"):
    loader = TextLoader(path)
    documents = loader.load()

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,      # heading + content together
        chunk_overlap=50,
        separators=["\n##", "\n#", "\n"]
    )
    chunks = splitter.split_documents(documents)

    print(f"[DEBUG] Loaded {len(documents)} document(s), {len(chunks)} chunks")
    for i, c in enumerate(chunks[:2]):
        print(f"[DEBUG] Chunk {i+1} preview:\n{c.page_content[:200]}\n{'-'*50}")

    return chunks
